package il.ac.technion.cs.softwaredesign

fun main() {
    println("hello, world")
}