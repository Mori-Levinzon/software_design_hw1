package il.ac.technion.cs.softwaredesign

enum class Databases {
    TORRENTS,
    PEERS,
    STATS
}